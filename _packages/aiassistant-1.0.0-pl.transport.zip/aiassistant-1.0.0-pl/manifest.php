<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 web86

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'AI-ассистент каталога для MODX 2.8+ и MODX 3.

Плавающая кнопка открывает чат. Посетитель пишет бюджет, тираж, цвет и повод.
Компонент фильтрует JSON/XML/YML-фид или товары miniShop2 и передаёт модели только подходящие строки.
В ответе — текст, список товаров со ссылками и кнопки «Добавить в корзину» и «Оформить спецификацию».

Провайдеры: demo, OpenAI, YandexGPT, GigaChat и любой OpenAI-совместимый API.
Ключи остаются в системных настройках.

После установки откройте системные настройки пространства имён aiassistant.
aiassistant.debug прячет чат от посетителей и пишет подробный журнал в core/cache/aiassistant/debug.log. Чат остаётся у пользователя, вошедшего в админку.
Подробности — в README репозитория.
',
    'changelog' => '1.0.0
- Режим отладки aiassistant.debug: чат только для входа в админку и подробный журнал core/cache/aiassistant/debug.log.
- Первый выпуск компонента подбора сетов.
- MODX 2.8+ и MODX 3, один код.
- Провайдеры OpenAI, YandexGPT, GigaChat, OpenAI-compatible и локальный demo.
- Каталог из JSON, XML, YML или из ресурсов miniShop2.
- Фильтр перед запросом к модели и проверка артикулов по каталогу.
- Корзина miniShop2 и заявка на спецификацию.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '63ca57818683d5f6b41af6bf5fa3ab76',
      'native_key' => 'aiassistant',
      'filename' => 'modNamespace/d8f6bc0fcb79a7ed1281883ba43b5c09.vehicle',
      'namespace' => 'aiassistant',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e9f22c7a9fcd7a8e59bf26de2363a955',
      'native_key' => NULL,
      'filename' => 'modCategory/8efae894fd6854eabfabea71f50b098a.vehicle',
      'namespace' => 'aiassistant',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0553da46b10a22cebe6a14a2ed64fe5',
      'native_key' => 'aiassistant.enabled',
      'filename' => 'modSystemSetting/cfd4983d5ad3826f9b6492bc1c727f4a.vehicle',
      'namespace' => 'aiassistant',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '036c3e8eda5e78577a17e9e917ea1b7f',
      'native_key' => 'aiassistant.debug',
      'filename' => 'modSystemSetting/25cb05765ccea2b970a5e442c5999a02.vehicle',
      'namespace' => 'aiassistant',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60ba2992917e1e2e79dcdb2bb5ee44bf',
      'native_key' => 'aiassistant.assistant_name',
      'filename' => 'modSystemSetting/622d029cbbc3bc5676f8f68f05ca359c.vehicle',
      'namespace' => 'aiassistant',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2dd66cbd17f3f4673ec45f81342cdbe',
      'native_key' => 'aiassistant.position',
      'filename' => 'modSystemSetting/d1eb945cefc0a2f18c4cf185e9a84dd7.vehicle',
      'namespace' => 'aiassistant',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e91ad57edd13a51c9b41a32f9f05324',
      'native_key' => 'aiassistant.accent',
      'filename' => 'modSystemSetting/573800a70d30dfd79f7d1c21e3550d0c.vehicle',
      'namespace' => 'aiassistant',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68d064ae0b3199eb75b794796e514430',
      'native_key' => 'aiassistant.show_templates',
      'filename' => 'modSystemSetting/0cf9db1f6b82d8c8ac267f134eb86d14.vehicle',
      'namespace' => 'aiassistant',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7ed013fb8b4c215fe489ec048c5a760',
      'native_key' => 'aiassistant.hide_templates',
      'filename' => 'modSystemSetting/8bfcaab360aeb1d7addccb8067d03526.vehicle',
      'namespace' => 'aiassistant',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eb2a9f8f022abb14014ea8b28a4b44c',
      'native_key' => 'aiassistant.welcome_text',
      'filename' => 'modSystemSetting/ed5833c970e88fd8fb7b78ab2eddaac0.vehicle',
      'namespace' => 'aiassistant',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a5342fa047e6076a782b18403ab0b84',
      'native_key' => 'aiassistant.placeholder',
      'filename' => 'modSystemSetting/2db53057a48b14a794390ca77be5d111.vehicle',
      'namespace' => 'aiassistant',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59a79a293b9cf5804f51bf6dc16e0fda',
      'native_key' => 'aiassistant.hint',
      'filename' => 'modSystemSetting/79fb688401577221cdcc72d01b01b36f.vehicle',
      'namespace' => 'aiassistant',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '697d51ef16a21791165b75acaf6f6629',
      'native_key' => 'aiassistant.status_text',
      'filename' => 'modSystemSetting/860881693cd7fb69341ed0281b86ddbf.vehicle',
      'namespace' => 'aiassistant',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '344e1d667d4a0b4eec8de92763de6b40',
      'native_key' => 'aiassistant.provider',
      'filename' => 'modSystemSetting/09bee620b91b141f057130070ebf3284.vehicle',
      'namespace' => 'aiassistant',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6e424637c2524389bad7b119fcf29d3',
      'native_key' => 'aiassistant.api_key',
      'filename' => 'modSystemSetting/6ed4a134281ed5a886e58ea87305e94e.vehicle',
      'namespace' => 'aiassistant',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9174d39d8268890d04c86277aa6a26e',
      'native_key' => 'aiassistant.api_base',
      'filename' => 'modSystemSetting/7c40f26cf0297e6306142e30865f7658.vehicle',
      'namespace' => 'aiassistant',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22c0f67278968e514c2a93ec64b0a1f9',
      'native_key' => 'aiassistant.model',
      'filename' => 'modSystemSetting/ecc9ec09873ea9d173ac482e426d1342.vehicle',
      'namespace' => 'aiassistant',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6ecc108ffb4f2302be4a73bd538ebc1',
      'native_key' => 'aiassistant.folder_id',
      'filename' => 'modSystemSetting/297b2e1a42256c4cf769523ffcd67ea7.vehicle',
      'namespace' => 'aiassistant',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71c42209582ffa61cf2bd61f07d72f4f',
      'native_key' => 'aiassistant.auth_mode',
      'filename' => 'modSystemSetting/01f20b008959ff4dbd361a86cc52aaf3.vehicle',
      'namespace' => 'aiassistant',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38269b197a650993ee973c87ca2b220c',
      'native_key' => 'aiassistant.gigachat_scope',
      'filename' => 'modSystemSetting/cbeaded0915040303ef8a8b7fc2e6891.vehicle',
      'namespace' => 'aiassistant',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a568fa38cac9b84505f3cdb2b09bd23',
      'native_key' => 'aiassistant.oauth_url',
      'filename' => 'modSystemSetting/84e14c3a5fa38c7267ce5dc92e4feabc.vehicle',
      'namespace' => 'aiassistant',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e81d05f9c1f9256915504102d77b03e2',
      'native_key' => 'aiassistant.temperature',
      'filename' => 'modSystemSetting/dfed326abc4e75018f962854a95e99cd.vehicle',
      'namespace' => 'aiassistant',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf67103b2fb33d604d7435368dea74d3',
      'native_key' => 'aiassistant.max_tokens',
      'filename' => 'modSystemSetting/d9cc102a9b2c3a97d6a5bec622077a6a.vehicle',
      'namespace' => 'aiassistant',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6bdf813f96b0cb98e3e6e2544f46786',
      'native_key' => 'aiassistant.timeout',
      'filename' => 'modSystemSetting/499e383ba43870bee474bf769b262c54.vehicle',
      'namespace' => 'aiassistant',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb0325ea1abf2e07c5e80e06f08562dd',
      'native_key' => 'aiassistant.ssl_verify',
      'filename' => 'modSystemSetting/a6ebef21f9a6746b5c32616179f15a97.vehicle',
      'namespace' => 'aiassistant',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbc043a3bf55ad2c62723b9988ab3279',
      'native_key' => 'aiassistant.ssl_cainfo',
      'filename' => 'modSystemSetting/856163dd69de4649ee6249947cc9bd13.vehicle',
      'namespace' => 'aiassistant',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0268f7e0567f407fb104183ff159a684',
      'native_key' => 'aiassistant.json_mode',
      'filename' => 'modSystemSetting/c8983623b70086975519dc468d52c38f.vehicle',
      'namespace' => 'aiassistant',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76a2992d6be0eb5fd797948cf715142b',
      'native_key' => 'aiassistant.fallback',
      'filename' => 'modSystemSetting/15ae90e6068b1606d993ae7c593ad8a6.vehicle',
      'namespace' => 'aiassistant',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bb1d3f964fc7f21c3f10b1dcde14b8b',
      'native_key' => 'aiassistant.catalog_source',
      'filename' => 'modSystemSetting/cb67ade7773e0f037d2fd10b3c760f24.vehicle',
      'namespace' => 'aiassistant',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e77346f44269238869adc8a1ae8e2c6f',
      'native_key' => 'aiassistant.feed_url',
      'filename' => 'modSystemSetting/03b79f81a333643073571b91d27f7efe.vehicle',
      'namespace' => 'aiassistant',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44f8720dddf54c49205fea1503984872',
      'native_key' => 'aiassistant.feed_format',
      'filename' => 'modSystemSetting/f017785954f776a8f9805456cc93d25c.vehicle',
      'namespace' => 'aiassistant',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2f3725f91a291a5688592fc8038f6af',
      'native_key' => 'aiassistant.feed_cache_ttl',
      'filename' => 'modSystemSetting/b38c6ad96a5a7f5de33cc832600b64d7.vehicle',
      'namespace' => 'aiassistant',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e78732637234a15d0b60f4f7bdc63dd6',
      'native_key' => 'aiassistant.feed_basic_user',
      'filename' => 'modSystemSetting/18e3e6bd053445045f49c4ea289d512e.vehicle',
      'namespace' => 'aiassistant',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ca86677c27ed04b2590347963166aec',
      'native_key' => 'aiassistant.feed_basic_pass',
      'filename' => 'modSystemSetting/c2787780fd21dafae6d53d613918d98c.vehicle',
      'namespace' => 'aiassistant',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d3a7c7dfebb2de7912bd5f4aa14bb11',
      'native_key' => 'aiassistant.parents',
      'filename' => 'modSystemSetting/1c53c0916f42477ce90c34ae8de1b92f.vehicle',
      'namespace' => 'aiassistant',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c94b7748a8523ec3b9944c8e9dc31ca4',
      'native_key' => 'aiassistant.depth',
      'filename' => 'modSystemSetting/8c5030006380c05a5cad5b1db22cdcde.vehicle',
      'namespace' => 'aiassistant',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac3d3a33087b4a3d73ea613806389733',
      'native_key' => 'aiassistant.context',
      'filename' => 'modSystemSetting/9263f9206c51976b04645a4ee4e193a5.vehicle',
      'namespace' => 'aiassistant',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7203e70861c04654c94dc45e15530fb5',
      'native_key' => 'aiassistant.class_key',
      'filename' => 'modSystemSetting/4d50a9ada6a6929a7a174ee4e46bae6e.vehicle',
      'namespace' => 'aiassistant',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36eb53f3dd067b153e5b62fcb812ecb6',
      'native_key' => 'aiassistant.template',
      'filename' => 'modSystemSetting/848079983fce422e96a5e07e7bccf105.vehicle',
      'namespace' => 'aiassistant',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '397b06be6db7445741f27ba5369c317f',
      'native_key' => 'aiassistant.tv_article',
      'filename' => 'modSystemSetting/099896268007f76749f7f899ff00846b.vehicle',
      'namespace' => 'aiassistant',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31d261fe6a09e053d4f3162ea7005ba5',
      'native_key' => 'aiassistant.tv_price',
      'filename' => 'modSystemSetting/2855c1dac389ff35c4b4979cf07b80a6.vehicle',
      'namespace' => 'aiassistant',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1c5fb9b92b18bf70d5485edc6018017',
      'native_key' => 'aiassistant.tv_color',
      'filename' => 'modSystemSetting/ee2deb7268818c1f998bd0b6b4f75bea.vehicle',
      'namespace' => 'aiassistant',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b230f7c70ecb2588a124e37d00b1ca77',
      'native_key' => 'aiassistant.tv_image',
      'filename' => 'modSystemSetting/9fc440dde48561dfbb601f6ca76c70c0.vehicle',
      'namespace' => 'aiassistant',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '178c5062c86294712a7e8b868bafe925',
      'native_key' => 'aiassistant.option_color',
      'filename' => 'modSystemSetting/2d67edb3c9ed6600da08b3bd994f6621.vehicle',
      'namespace' => 'aiassistant',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6a00f5af96bc131760e1248c7b74e7d',
      'native_key' => 'aiassistant.image_base',
      'filename' => 'modSystemSetting/cc259d5c6022538da2ad44ca6c5bbc9d.vehicle',
      'namespace' => 'aiassistant',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd70e67000ffa2a4815a6dda3bec0fd08',
      'native_key' => 'aiassistant.include_tvs',
      'filename' => 'modSystemSetting/e179f55dc41cafdd829e45c3835fc4ef.vehicle',
      'namespace' => 'aiassistant',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1acdac8628991034f241945632fd031',
      'native_key' => 'aiassistant.max_candidates',
      'filename' => 'modSystemSetting/a218a37b68f168ede23e2b190a56ad0b.vehicle',
      'namespace' => 'aiassistant',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb27fae0764f437a0b7607e941be0f32',
      'native_key' => 'aiassistant.max_in_set',
      'filename' => 'modSystemSetting/5a4ba70c3dc195ad06e023b7147ad6ba.vehicle',
      'namespace' => 'aiassistant',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4513da567f4738a2750b6d1592a5c01',
      'native_key' => 'aiassistant.themes',
      'filename' => 'modSystemSetting/671e81db86ed20044c93b7199c71c369.vehicle',
      'namespace' => 'aiassistant',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57e985e392f180cd1c652be5c120ceea',
      'native_key' => 'aiassistant.rules_chunk',
      'filename' => 'modSystemSetting/cb9bf4a3601c52ade23124c842519e46.vehicle',
      'namespace' => 'aiassistant',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c74045019aa93143e83dfbf95589937',
      'native_key' => 'aiassistant.currency',
      'filename' => 'modSystemSetting/c6878d29ebe564d539a71ae96ad9bb0c.vehicle',
      'namespace' => 'aiassistant',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cfa143d2f31f392a1b91bb1f67855c3',
      'native_key' => 'aiassistant.cart_enabled',
      'filename' => 'modSystemSetting/65b6422a1fa55e15631f3e86be3d7d5d.vehicle',
      'namespace' => 'aiassistant',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ad095f2768b8914f33db0c425dcce6e',
      'native_key' => 'aiassistant.cart_mode',
      'filename' => 'modSystemSetting/71c5e1ad8c11998a22108f27053e4e63.vehicle',
      'namespace' => 'aiassistant',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '486f7c82d2b03a77e9316cc12cc589f7',
      'native_key' => 'aiassistant.cart_url',
      'filename' => 'modSystemSetting/9d7cbc5e89e3877ed1c8f53d4cd90eea.vehicle',
      'namespace' => 'aiassistant',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7040157200be1c5c353df107839993de',
      'native_key' => 'aiassistant.spec_enabled',
      'filename' => 'modSystemSetting/9f1fd4a8c7e946f7350f3900052d98f5.vehicle',
      'namespace' => 'aiassistant',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e5953be6b2c495b633f1bb0a3b55922',
      'native_key' => 'aiassistant.spec_email',
      'filename' => 'modSystemSetting/569e0b303ebec654f76d5082e6c2d081.vehicle',
      'namespace' => 'aiassistant',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3d5242f077c3e3f3c68fea752827a22',
      'native_key' => 'aiassistant.max_messages',
      'filename' => 'modSystemSetting/06d5eaddf838f2b98ff69fafadf89c06.vehicle',
      'namespace' => 'aiassistant',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68724815f64d31c9962fbdd299f666c6',
      'native_key' => 'aiassistant.rate_limit',
      'filename' => 'modSystemSetting/8508798ffb06b784da072ef284157bad.vehicle',
      'namespace' => 'aiassistant',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab6010d1d9370c782a115e7ed08f6fcf',
      'native_key' => 'aiassistant.log_enabled',
      'filename' => 'modSystemSetting/e6a309b03458b6b538f4ba8c44adbf7a.vehicle',
      'namespace' => 'aiassistant',
    ),
  ),
);